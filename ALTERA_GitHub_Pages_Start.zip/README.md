# ALTERA – Another Life (nettbasert test)

Dette er en **statisk testversjon** basert på ALTERA 5.6.

## Publisering via GitHub Pages
1. Opprett et offentlig repository kalt `altera-another-life` på GitHub.
2. Last opp `index.html` og `.nojekyll` til roten av repositoryet.
3. Gå til Settings → Pages → Build and deployment.
4. Velg **Deploy from a branch**, branch **main**, folder **/(root)** og Save.
5. Nettadressen blir normalt `https://DITT-BRUKERNAVN.github.io/altera-another-life/`.

GitHub Pages kjører ikke Node.js-serveren. Dette er derfor en test av nettgrensesnittet, ikke full flerspillerfunksjonalitet. Noen 3D-funksjoner bruker ekstern Three.js-CDN og trenger nettilgang.

**Personvern:** GitHub Pages-nettsiden er offentlig. Ikke legg inn passord, API-nøkler eller private data.
